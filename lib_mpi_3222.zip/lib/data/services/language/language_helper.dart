class LanguageHelper {
  static const String vi = "vi";
  static const String en = "en";
}
