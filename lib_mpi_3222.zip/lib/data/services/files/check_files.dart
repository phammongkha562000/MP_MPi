class FileCheck {
  static const String pdf = "PDF";
  static const String docx = "DOCX";
  static const String xlsx = "XLSX";
  static const String unknown = "unknown";
}
