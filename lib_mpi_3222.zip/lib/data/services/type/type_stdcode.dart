class TypeStdCode {
  static const String typeHr = "HRLEAVETYPE";
  static const String typeSVC = "SVCTYPE";
  static const String typePRIORITY = "PRIORITY";
  static const String typeSrStatus = "SRSTATUS";
  static const String typeTimesheets = 'TSPOSTTYPE';
  static const String typeITService = "ITSERVICE";
  static const String typeDOCGENSTATUSTSPOSTTYPE = "DOCGENSTATUS,TSPOSTTYPE";
  static const String typeCOSTCENTER= "COSTCENTER";
}
