// ignore_for_file: constant_identifier_names

class TypeService {
  static const String qst = "QST";
  static const String new_function = "NEW";
  static const String err = "ERR";
  static const String per = "PER";
  static const String oth = "OTH";
}
