class TypeDateWidget {
  static const int nextMonth = 0;
  static const int previousMonth = 1;
}
