// ignore_for_file: constant_identifier_names

class TypeITService {
  static const String infra = "INFRA";
  static const String email = "EMAIL";
  static const String intra_mps = "INTRA";
  static const String fmbp = "FMBP";
  static const String igls_WMS = "WMS";
  static const String igls_OMS = "OMS";
  static const String igls_TMS = "TMS";
  static const String igls_FMS = "FMS";
  static const String igls_WP = "WP";
  static const String mplw = "MPLW";
  static const String assethandover = "ASSETHANDOVER";
}
