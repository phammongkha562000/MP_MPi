export 'gallerys_response.dart';
