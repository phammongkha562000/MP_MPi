class ServerInfo {
  String? sso;
  String? notificationServerName;
  String? wifi;
  String? ssid;
  String? serverHub;
  String? serverUpload;
  ServerInfo(
      {this.sso,
      this.notificationServerName,
      this.wifi,
      this.ssid,
      this.serverHub,
      this.serverUpload});
}
