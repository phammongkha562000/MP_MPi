class TypeStdCode {
  static const String typeHr = "HRLEAVETYPE";
  static const String typeSVC = "SVCTYPE";
  
}
