part of 'contact_bloc.dart';

class ContactEvent extends Equatable {
  const ContactEvent();

  @override
  List<Object> get props => [];
}

class ContactViewLoaded extends ContactEvent {}
